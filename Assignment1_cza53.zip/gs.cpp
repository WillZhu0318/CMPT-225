#include <iostream>   
#include "char_stack.h"
using namespace std;

void output_error(char arr1[],int index1,int d)
{
  for(int i=0;i<index1;i++)
    {
      cout<<arr1[i];
    }
  cout<<endl;
  for(int l=0;l<index1;l++)
    {
      cout<<" ";
    }
  for(int m=index1;m<d-index1;m++)
    {
      cout<<arr1[m];
    }
}


int main()
{
  int ind=0;
  char arr[300];
  char_stack S;
  char c;
  int index=0;
  int d=cin.gcount();
  while (cin.peek()<0){
    cin.getline(arr,300);
    ind++;
    while (arr[index]!='\0'){
      c=arr[index++];
    if(c=='(' || c=='[' || c=='{'){
      S.push(c);
    }
    else if(c==')'||c==']' || c=='}'){
      if (S.empty()){
        cout<<"Error on line "<<ind;
	cout<<"Too many "<<c;
      }
      char l;
      l=S.pop();
      if ((l+1)!=c){
	cout<<"Error on line "<<ind;
	cout<<"Too many "<<c;
	cout<<"Read"<<c<<"expected"<<char(l+1)<<'\n';
	output_error(arr,index,d);
    return 0;
      }
      if((l+2)!=c){
	cout<<"Error on line "<<ind;
	cout<<"Too many "<<c;
	cout<<"Read"<<c<<"expected"<<char(l+2)<<'\n';
	output_error(arr,index,d);
    return 0;
      }
    }
    }
  }
    if(!S.empty()){
    c=S.pop();
    cout<<"Error on line "<<ind;
    cout<<"Too many"<<c<<endl;
    output_error(arr,index,d);
    return 0;
  }
  cout<<"No Error Found";
  return 0;
}







